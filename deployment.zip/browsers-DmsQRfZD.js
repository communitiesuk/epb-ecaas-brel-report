//#region __vite-optional-peer-dep:proxy-agent:@puppeteer/browsers
throw new Error(`Could not resolve "proxy-agent" imported by "@puppeteer/browsers". Is it installed?`);
//#endregion
export {};
